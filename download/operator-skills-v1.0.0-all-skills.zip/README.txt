Operator Skills — all 22 skills
===============================

claude.ai installs ONE skill per upload, so this bundle contains 22 separate
zip files rather than a single one you can upload as-is.

To install:
  1. Unzip this file.
  2. In Claude, click Customize (bottom left) > Skills > + > Upload a skill.
  3. Choose one of the 22 zips inside. Repeat for each one you want.
  4. Toggle each skill on in your Skills list.

Start with business-brief.zip. It interviews you once and writes a file the
other 21 skills read, so you never explain your business twice.

Full instructions: docs/install-claude-ai.md
